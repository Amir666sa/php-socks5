<?php
error_reporting(0);
//========================== // token // ==============================
define('5024774686:AAFymudTpVwFUYdZM1H3hdBEW6_VuyWPvU4');//توکن بزارید
//========================== // config // ==============================
$admin = ['911478720','2100323908']; // ها را ماننده این الگورتیم بگذارید ادمین اصلی ایدی اول است
$usernamebot = '@Smsbom_saCheese_bot'; // یوزرنیم ربات
$channel = 'testbotmyahmad'; // ایدی کانال بدون @
$channelname = 'botbom'; // تگزو سورس
$botname = 'Smsbom'; //تگزو سوری
$adpush = 'fake_XQ_QM'; //ایدی پشتیبانی بدون@
$web = 'https://domin.com/پوشه/bot.php'; // آدرس محل قرار گیری سورس همراه با پوشه
$logozir = 'https://telegra.ph/file/a10e4ab4e721641306f04.jpg';//لینک عکس زیر مجموعه گیری
$db_user = 'sayazdan_amir667'; //نام یوزر
$pass = 'AHMAD2005'; //رمز دیتابیس
$db_name = 'sayazdan_amir667'; //نام دیتا
//========================== // database // ==============================
$connect = new mysqli('localhost',$db_name,$pass,$db_user);
$connect->query("SET NAMES 'utf8'"); $connect->set_charset('utf8mb4');
?>i